## Why
I'm annoyed at the lack of desktop app for voice, like hangouts had.

## What does it do
It just lets you keep voice open without a chrome browser. It will also check the dom for notifications and display a badge in the task bar.

## Support
Currently supports both OSX and Windows 10

## Install
Theres no package so you have to run from source.

`git clone git@github.com:Jerrkawz/google-voice-desktop-app.git`

`npm install`

`npm start`

## Screenshots
![Windows](/images/windows.png?raw=true")
